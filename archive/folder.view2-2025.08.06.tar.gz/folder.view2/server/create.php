<?php
    require_once("/usr/local/emhttp/plugins/folder.view2/server/lib.php");
    updateFolder($_POST['type'], $_POST['content']);
?>
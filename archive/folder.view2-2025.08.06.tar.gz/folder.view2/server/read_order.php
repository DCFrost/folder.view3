<?php
    require_once("/usr/local/emhttp/plugins/folder.view2/server/lib.php");
    echo readUserPrefs($_GET['type']);
?>